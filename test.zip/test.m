system='simscapetest';
T=10:-0.1:0.1;
obj.F=1./T;
load_system(system);
set_param(system,'stoptime','30');
set_param(system,'MaxConsecutiveZCsMsg','none'); %toggle off consecutive zero crossing
set_param(strcat(system,'/Pulse Generator'),'Period','T');
set_param(strcat(system,'/Pulse Generator'),'PulseWidth','1./T');
simout=sim(system,'SrcWorkspace','current');